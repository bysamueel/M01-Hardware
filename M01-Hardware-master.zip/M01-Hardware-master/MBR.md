# REGISTRO DE ARRANQUE PRINCIPAL (MBR)

* ***2 bytes*** = Firma de unidad arrancable ("55h AAh" en hexadecimal) 

* ***64 bytes*** = Tabla de particiones (4 registros que definen cada una de las particiones primarias) 

* ***446 bytes*** = Código máquina (gestor de arranque) 
