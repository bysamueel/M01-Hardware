# DESMONTAJE DE UNA CAJA
**- Probamos el TESTER**  
Desmontamos el PC , procediendo a sacar la capa lateral , (OPUESTA A DONDE ESTA COLOCADA LA PLACA BASE) , con un destornillador Estrella , y dejamos los tornillos en un lugar que no se caigan ni se pierdan , es recomendable dejarlos en un teclado entre las teclas , ya que si estamos desmontando un PC tendremos un teclado a mano, dejamos los tornillos en el teclado y ponemos las manos sobre la tapa , estirando hacia nosotros, de esta manera la capa saldrá, encontramos la fuente de alimentacion con cables que lo conectan a la placa base , la cpu , el ventilador , el disco, etc..
  
**Nos comentó que en la placa base podiamos saber muchas cosas sobre ella , que modelo era , la marca , que ddr usaba,
y las revoluciones**  
  
Buscamos en el Explorador la placa base que tiene el PC que era un GiGAByte H81M-S2PV , vimos que en la parte inferior encontrabamos que ddr tiene , que era un DDR3 , no tenia dual channel , tiene 4 puertos SATA y Revolucions 2.0  
  
Cogemos el TESTER y diferenciamos el simbolo de Corriente Continua con Alterna  
**_**  
**...**   --> **CORRENT CONTINUA**  

**～**  
**...**   --> **CORRENT ALTERNA**

Probamos el TESTER en diferentes piezas y lugares del PC para comprobar si estan correctamente y si funcionan perfectamente.  

Colocamos la salida del cable rojo en la entrada del voltaje (rojo) , en la otra entrada no ya que calcula la intensidad en amperios y no queremos calcular la intensidad
Colocamos la salida del cable negro en la entrada del voltaje (negro) , luego seleccionamos con la rueda que tenemos la funcion que queremos realizar con el TESTER DIGITAL , ya sea Corriente Continua o Corriente Alterna.  
Y por ultimo hacemos contacto con las pinzas

Buscamos el Manual de la Placa Base que tiene el PC para guiarnos y entender como funciona y que caracteristicas tiene la placa base. Podemos ir dando una ojeada a las pàginas ver como va cada cosa y mirar cosas que son muy importante de montar , como el frontpanel , la motherboard layout , el diagrama de la placa , 

Hacemos una prueba para saber si funciona el boton de encendido quitando el pequeño conector "POWER SW" con cable naranja (+) y blanco (-), los cables blancos siempre son negativos y los cables de color son positivos , procedemos a hacer contacto las pinzar con los cables y esperar a ver si el TESTER pita , si pita quiere decir que el cable esta en perfectas condiciones.  

Luego probamos el Power Supply Tester , desconectamos en cable de 24 pines que esta enchufado a la placa base , apretando una especie de pinza , y estirando hacia arriba y de lado a lado.
Luego cogemos , y la conectamos al Power Supply Tester , y este nos dira su voltaje y su estado  
