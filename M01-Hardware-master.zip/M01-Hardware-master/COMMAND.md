# Comandes Linux
- **whoami**: saber l'usuari en que estic.
- **who**: dispositius connectats al dispositiu.
- **su -**: usuari root.
- **passwd**: canviar contrasenya.
- **sudo useradd**: crear usuari.
- **sudo passwd "usuari"**: canviar contrasenya d'un usuari.
- **mkdir**: crear directori.
- **rmdir**: eliminar directori.
- **pwd**: saber en quin directori estic.
- **touch**: crear arxiu. 
- **cat**: llegir contingut d'un arxiu.
- **rm**: eliminar arxiu.
- **nmap "IP"**: saber quins ports estan oberts.

ARXIU de **[Marc Carrión Profile](https://github.com/carrionm/Hardware)**
