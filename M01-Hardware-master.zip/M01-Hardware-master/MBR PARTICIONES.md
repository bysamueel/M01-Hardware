# BIOS MBR DOS

**MBR DOS** : tiene un limite de 2TB por partición

## MBR DOS 

**REGLAS**

- **4** particiones primàrias como máximo

- **1** de las primarias tiene la posibilidad a ser **extended**

- Dentro de la particion extended puede haber **n logicas**

- **OBLIGATORIAMENTE** una partición primaria debe ser **Active**    
   
   **BOOT Manager** - es una utilidad en los sistemas operativos de **WINDOWS** que permite a los usuarios seleccionar el sistema 
   operativo en el arranque.
   
   **GRUB** - Su misión es cargar el kernel de un sistema operativo y pasarle el control de ejecución para que continúe con el 
   resto del proceso de inicialización. **LINUX**
  
