# ¿Qué es GNU?
GNU es un sistema operativo anunciado en el año 1983 por Richard Stallman, que se caracteriza por estar compuesto completamente por software libre.

GNU es un sistema operativo de software libre, es decir, respeta la libertad de los usuarios. El sistema operativo GNU consiste en paquetes de GNU (programas publicados específicamente por el proyecto GNU) además de software libre publicado por otras personas. El desarrollo de GNU ha permitido que se pueda utilizar un ordenador sin software que atropelle nuestra libertad.
# ¿Qué es GPL?
***General Public Licence***

Los programas de ordenador suelen distribuirse con licencias propietarias o cerradas.

Estas licencias son intransferibles y no exclusivas, es decir, no eres propietario del programa, sólo tienes derecho a usarlo en un ordenador o tantos como permita expresamente la licencia y no puedes modificar el programa ni distribuirlo.

La licencia GPL o General Public License, desarrollada por la FSF o Free Software Foundation, es completamente diferente. Puedes instalar y usar un programa GPL en un ordenador o en tantos como te apetezca, sin limitación. También puedes modificar el programa para adaptarlo a lo que tu quieras que haga. Además, podrás distribuir el programa GPL tal cual o después de haberlo modificado.

Puedes hacer esto, regalando el programa o vendiéndolo, tu única obligación, es facilitar siempre con el programa binario el código fuente, es decir, el programa de forma que pueda ser leido por un programador.
